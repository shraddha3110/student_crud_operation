
<?php
   require_once('includes/config.php');

   $errors = array();
  if(isset($_POST['add']))
{
  $errors = validate_add();
  if(count($errors) == 0)
  {
    //$src = $_FILES['photo']['tmp_name'];
    //$dest = 'img/'.$_FILES['photo']['name'];
    //$photo = '';
    //if(move_uploaded_file($src,$dest))
      //$photo = $_FILES['photo']['name'];
      
    $sql = "INSERT INTO students SET name='".$_POST['name']."',mobile='".$_POST['mobile']."',
    email='".$_POST['email']."', address='".$_POST['address']."' , gender='".$_POST['gender']."',created=NOW()";
   
      //print_r($sql);


    if(mysqli_query($con,$sql))
     {?>
      <script type="text/javascript">

                window.location.href="dashboard.php";

      </script>?>

    <?php   }

    else
     
      echo "Could not add Student Data.";
  }
  
}
?>
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/style.css">

</head>
<body>
  <div class="container-fuild">
           <form class="form" method="post" role="form">
           	  
                <center><h2 style="margin-bottom: 0">Fill Student Details</h2></center>
                  <div class="form-group">
                     <label for="name ">Name</label>
                       <input type="text" id="name" placeholder="Enter Name" class="form-control"  name="name"autofocus value="<?php echo isset($_POST['name'])? $_POST['name']:''; ?>" />
                  </div>

                   <div class="form-group">
                    <label for="password">Password</label>
                      <input type="password" placeholder="Enter Password" class="form-control" name="password" value="<?php echo isset($_POST['password'])? $_POST['password']:''; ?>">
                  </div>

                  <div class="form-group">
                    <label for="mnumber">Mobile Number</label>
                      <input type="mnumber" placeholder="Enter Mobile number" class="form-control" name="mobile" value="<?php echo isset($_POST['mobile'])? $_POST['mobile']:''; ?>">
                  </div>

                 
                

                <div class="form-group">
                    <label for="email" >Email Id </label>
                        <input type="email" id="email" placeholder="Enter Email" class="form-control" name= "email" value="<?php echo isset($_POST['email'])? $_POST['email']:''; ?>">
                   
                </div>
                <div class="form-group">
                	<label for="address" >Address</label>
                	
                	   <textarea class="form-control" id="address" name="address" value="<?php echo isset($_POST['address'])? $_POST['address']:''; ?>"></textarea>
                    
                </div>

                <div class="form-group">
                	  <label for="photo" class="col-md-6">Photo</label>
                	  <div class="col-md-3">
                	  	<input type="file" name="photo">
                	  </div>
                 </div>
                

                <div class="form-group">
                 <div class="row" >
                      <div class="col-md-4">
                          <label class="radio-inline">
                              <input type="radio" name="gender" value="Female" <?php echo isset($_POST['gender']) && $_POST['gender']=='F'?'checked':''; ?> />Female
                           </label>
                       </div>
                       <div class="col-md-4">
                           <label class="radio-inline">
                               <input type="radio"  name="gender" value="Male"<?php echo isset($_POST['gender']) && $_POST['gender']=='M'?'checked':''; ?> />Male
                            </label>
                       </div>
                 </div>
                </div> 
               <center> <button type="submit" name="add" class="btn btn-primary" btn-block>Add</button></center>
            </form> 
        </div> 
	</form>	