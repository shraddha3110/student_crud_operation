<?php
require_once('includes/config.php');
//if(!isset($_SESSION['auth']['id']))
//{
	//header("Location:login.php");
	//exit;
//}
echo "";
$sql = "SELECT * FROM students WHERE id=".$_GET['id'];
print_r($_GET['id']);
$result = mysqli_query($con,$sql);
$row = mysqli_affected_rows($con);
mysqli_query($con,"DELETE FROM students WHERE id=".$_GET['id']);

if(mysqli_affected_rows($con)>0)
{ 
    //unlink('img/'. $row['photo']);
	echo "Student deleted successfully";
}
else
   echo "Could not delete student";
?>