<?php
   require_once('includes/config.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/style.css">

</head>
<body>
	<div class="container">
          <main>
              <nav class="navbar navbar-expand-md navbar-dark bg-dark">
               <a href="#" class="navbar-brand"><h1>DASHBOARD</h1></a>
               
                <a type="submit" class="btn btn-primary btn-md" href="add.php" style="margin-left: 600px;">Add Student</a>&nbsp;
                 <a type="submit" class="btn btn-danger btn-md" href="logout.php">Logout</a>
                
            </nav>
          	<!--<center><h1 class="bg-dark text-light rounded">DASHBOARD</h1></center>-->
                  
                 <div class="table bg-light text-dark p-0">
                   <table class="table" align="center" border="2" >
                   	<!--<div class="p-3 mb-2 bg-light text-dark">-->
                        <tr>
                           <!-- <th class="first "><input type="checkbox" class="checkbox toggle" /></th>-->
                           <th>Sr. No.</th>
                           <th>Name</th>
                           <th>Moblile NO.</th>
                           <th>Email Id</th>
                           <th>Address</th>
                           <th>Photo</th>
                           <th>Gender</th>
                           <th><center>Action</center></th>
                         </tr>
                         <?php 
                            $sql= "SELECT * FROM students";
                            $result= mysqli_query($con,$sql);
                             //print_r($sql); 
                             //exit;
                            //print_r($result);
                             while($row = @mysqli_fetch_array($result,MYSQLI_ASSOC))
                             {
                          ?>  
                         <tr class="new">
                           <td><input type="checkbox" name="id" /></td>
                    
                               
                               <td><?php echo $row['name']; ?></td>
                               <td><?php echo $row['mobile'] ?></td>
                               <td><?php echo $row['email']; ?></td>
                               <td><?php echo $row['address']; ?></td>
                               <td><?php echo "<img src='img/". $row['photo']."' width='60' height='60'>"; ?></td>
                               <td><?php echo $row['gender']; ?></td>
                              <td class="two" style="padding-left: 25px; ">
                              
                            
                                  <a type="submit" class="btn btn-primary btn-md" href="edit.php?id=<?php echo $row['id'] ?>">Edit</a>
                             <a type="submit" class="btn btn-danger btn-md" href="delete.php?id=<?php echo $row['id']; ?>" class="del_btn" >Delete</a></td>
                            <!--<a href="delete.php?id=<?php echo $row['id']; ?>" style="text-decoration:none;"> --->
                    



                     </tr>
                   <?php } ?>

                   <tr>

                    
    </tr>
                    
                  </table>
                </div>
              </div>
          </main>
      </div>
</body>
</html>