 <?php
// error_reporting(0);
 function validate_add()
{
	$errors=array();
	if(empty($_POST['name']))
	{
		$errors[] = "Please enter name";
	}
	elseif(!preg_match("#^[-A-Za-z']*$#",$_POST['name']))
		$errors[] = "Please enter valid  name";

	if(empty($_POST['mobile']))
	{
		$errors[]="Please enter mobile number";
	} 
	elseif(!preg_match("/^[+]?[1-9][0-9]{9,14}$/",$_POST['mobile']))
	     $errors[]="Please enter valid number";


	if(empty($_POST['email']))
	{
		$errors[] = "Please enter email address";
	}
	elseif(!filter_var($_POST['email'],FILTER_VALIDATE_EMAIL))
	{
		$errors[] = "Please enter valid email address";
	}
    //print_r($_FILES);

	//if($_FILES['photo']['error'] == 0)
	//{ 
		
		//$types = array('img/jpeg','image/png','image/gif','application/pdf','image/jpg');
		//if(!in_array($_FILES['photo']['type'],$types))
		//	$errors[] = "Please enter photo of type jpeg or png or gif or jpg";
		//echo "$types";
	//}

	return $errors;
}
?>