<?php
$con = mysqli_connect('localhost','root','') OR die('Could not connect to mysql server');
mysqli_select_db($con,'regi') OR die('Could not connect to database');
session_name('auth');
session_start();
//session_name('auth');
require_once('includes/validation.php');
?> 


