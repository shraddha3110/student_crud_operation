<?php
require_once("includes/config.php");

if(isset($_POST['login']))
{ print_r($_POST['email']);
   $sql= "SELECT * FROM students WHERE email='".$_POST['email']."' AND password ='".$_POST['password']."' ";
   $result= mysqli_query($con,$sql);
   if($result)
   $row= mysqli_fetch_assoc($result);
   
   if(isset($row['id']))
   {
     unset($row['password']); 
     $_SESSION['auth'] = $row;
      header('Location: dashboard.php');
    }
   else
   {
     echo "Login failed , please try again";
   }
   
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>login</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
	  <div class="container-fuild">
           <form class="log form "  method="post" role="form" enctype="multipart/form">
           	   <center><h2>LOGIN FORM</h2></center>
                  <div class="form-group">

                  	  <div class="form-group">
                         <label for="email" >Email Id </label>
                          <input type="email" id="email" placeholder="Enter Email" class="form-control" name= "email">
                        
                     </div>

                     <div class="form-group">
                    <label for="password">Password</label>
                      <input type="password" placeholder="Enter Password" class="form-control" 
                      name="password">
                  </div>
                  <div>
                   <center><input type="submit" name="login" value="login">
               </center>
                
                  </div>
           </form>
       </div>
</body>
</html>